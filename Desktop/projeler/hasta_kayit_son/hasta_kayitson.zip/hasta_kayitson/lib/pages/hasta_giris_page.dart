import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/hasta_controller.dart';
import 'hasta_kayit_page.dart';
import 'hasta_randevu_page.dart';

class HastaGirisPage extends StatelessWidget {
  HastaGirisPage({super.key});

  final HastaController controller = Get.find();
  final TextEditingController tcController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Hasta Girişi',
          style: TextStyle(color: Color.fromARGB(255, 65, 28, 214)),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 50),
            TextField(
              controller: tcController,
              decoration: const InputDecoration(
                labelText: 'TC Kimlik No',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
              keyboardType: TextInputType.number,
              maxLength: 11,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  final tc = tcController.text.trim();
                  if (tc.length != 11) {
                    Get.snackbar('Hata', 'TC Kimlik No 11 haneli olmalıdır');
                    return;
                  }

                  final hasta = await controller.hastaAra(tc);
                  if (hasta != null) {
                    Get.to(() => HastaRandevuPage(hasta: hasta));
                  } else {
                    Get.defaultDialog(
                      title: 'Hasta Bulunamadı',
                      middleText:
                          'Bu TC ile kayıtlı hasta bulunamadı. Yeni kayıt oluşturmak ister misiniz?',
                      textCancel: 'İptal',
                      textConfirm: 'Kayıt Ol',
                      onConfirm: () {
                        Get.back();
                        Get.to(() => HastaKayitPage());
                      },
                    );
                  }
                },
                icon: const Icon(Icons.login),
                label: const Text('Giriş Yap', style: TextStyle(fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                Get.to(() => HastaKayitPage());
              },
              child: const Text('Henüz kaydınız yok mu? Kayıt olun'),
            ),
          ],
        ),
      ),
    );
  }
}
