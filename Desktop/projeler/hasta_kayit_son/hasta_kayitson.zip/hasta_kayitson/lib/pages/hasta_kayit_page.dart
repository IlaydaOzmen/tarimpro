import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/hasta_controller.dart';
import '../controller/doktor_controller.dart';

class HastaKayitPage extends StatelessWidget {
  HastaKayitPage({super.key});

  final HastaController controller = Get.find();
  final DoktorController doktorController = Get.find();

  @override
  Widget build(BuildContext context) {
    doktorController.doktorlariYukle();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Hasta Kayıt',
          style: TextStyle(
            fontSize: 24,
            color: Color.fromARGB(255, 65, 28, 214),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: controller.formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: controller.adSoyadController,
                decoration: const InputDecoration(
                  labelText: 'Ad Soyad',
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val == null || val.trim().isEmpty 
                  ? 'Ad soyad boş olamaz' 
                  : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: controller.tcController,
                decoration: const InputDecoration(
                  labelText: 'TC Kimlik No',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                maxLength: 11,
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'TC boş bırakılamaz';
                  }
                  if (val.trim().length != 11) {
                    return 'TC 11 hane olmalı';
                  }
                  if (!RegExp(r'^[0-9]{11}).hasMatch(val.trim())) {
                    return 'TC sadece rakamlardan oluşmalı';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 10),
              Obx(() => DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Cinsiyet',
                  border: OutlineInputBorder(),
                ),
                value: controller.cinsiyet.value == '' 
                  ? null 
                  : controller.cinsiyet.value,
                items: controller.cinsiyetler
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (val) {
                  controller.cinsiyet.value = val ?? '';
                },
                validator: (val) => val == null || val.isEmpty 
                  ? 'Cinsiyet seçiniz' 
                  : null,
              )),
              const SizedBox(height: 10),
              TextFormField(
                controller: controller.adresController,
                decoration: const InputDecoration(
                  labelText: 'Adres',
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val == null || val.trim().isEmpty 
                  ? 'Adres boş bırakılamaz' 
                  : null,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Obx(() => DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Gün',
                        border: OutlineInputBorder(),
                      ),
                      value: controller.gun.value == '' 
                        ? null 
                        : controller.gun.value,
                      items: controller.gunler
                          .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                          .toList(),
                      onChanged: (val) => controller.gun.value = val ?? '',
                      validator: (val) => val == null || val.isEmpty 
                        ? 'Gün seçiniz' 
                        : null,
                    )),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Obx(() => DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Ay',
                        border: OutlineInputBorder(),
                      ),
                      value: controller.ay.value == '' 
                        ? null 
                        : controller.ay.value,
                      items: controller.aylar
                          .map((a) => DropdownMenuItem(value: a, child: Text(a)))
                          .toList(),
                      onChanged: (val) => controller.ay.value = val ?? '',
                      validator: (val) => val == null || val.isEmpty 
                        ? 'Ay seçiniz' 
                        : null,
                    )),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Obx(() => DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Yıl',
                        border: OutlineInputBorder(),
                      ),
                      value: controller.yil.value == '' 
                        ? null 
                        : controller.yil.value,
                      items: controller.yillar
                          .map((y) => DropdownMenuItem(value: y, child: Text(y)))
                          .toList(),
                      onChanged: (val) => controller.yil.value = val ?? '',
                      validator: (val) => val == null || val.isEmpty 
                        ? 'Yıl seçiniz' 
                        : null,
                    )),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Obx(() => DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Poliklinik Seçin',
                  border: OutlineInputBorder(),
                ),
                value: controller.selectedPoliklinik.value.isEmpty 
                  ? null 
                  : controller.selectedPoliklinik.value,
                items: controller.poliklinikler
                    .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                    .toList(),
                onChanged: (val) {
                  controller.selectedPoliklinik.value = val ?? '';
                  controller.selectedDoktor.value = '';
                  doktorController.poliklinikDoktorlari(val ?? '');
                },
                validator: (val) => val == null || val.isEmpty 
                  ? 'Poliklinik seçiniz' 
                  : null,
              )),
              const SizedBox(height: 10),
              Obx(() => DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Doktor Seçin',
                  border: OutlineInputBorder(),
                ),
                value: controller.selectedDoktor.value.isEmpty 
                  ? null 
                  : controller.selectedDoktor.value,
                items: doktorController.filtrelenmisDoktorlar
                    .map((d) => DropdownMenuItem(
                      value: d['id'].toString(), 
                      child: Text(d['adSoyad'])
                    ))
                    .toList(),
                onChanged: (val) {
                  controller.selectedDoktor.value = val ?? '';
                },
                validator: (val) => val == null || val.isEmpty 
                  ? 'Doktor seçiniz' 
                  : null,
              )),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: controller.saveFormData,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  elevation: 4,
                ),
                child: const Text('Kaydet'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}