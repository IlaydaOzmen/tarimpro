import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/hasta_controller.dart';
import '../controller/doktor_controller.dart';

class HastaRandevuPage extends StatelessWidget {
  final Map<String, dynamic> hasta;

  HastaRandevuPage({super.key, required this.hasta});

  final HastaController hastaController = Get.find();
  final DoktorController doktorController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Hoşgeldiniz ${hasta['adSoyad']}')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kişisel Bilgileriniz',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 10),
                    Text('Ad Soyad: ${hasta['adSoyad']}'),
                    Text('TC: ${hasta['tc']}'),
                    Text('Doğum Tarihi: ${hasta['dogumTarihi']}'),
                    Text('Cinsiyet: ${hasta['cinsiyet']}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  _showRandevuDialog(context);
                },
                icon: const Icon(Icons.calendar_today),
                label: const Text('Randevu Al'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  _showRandevularimDialog(context);
                },
                icon: const Icon(Icons.list),
                label: const Text('Randevularım'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRandevuDialog(BuildContext context) {
    doktorController.doktorlariYukle();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Randevu Al'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Obx(
                () => DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Poliklinik Seçin',
                    border: OutlineInputBorder(),
                  ),
                  value: hastaController.selectedPoliklinik.value.isEmpty
                      ? null
                      : hastaController.selectedPoliklinik.value,
                  items: hastaController.poliklinikler
                      .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                      .toList(),
                  onChanged: (val) {
                    hastaController.selectedPoliklinik.value = val ?? '';
                    hastaController.selectedDoktor.value = '';
                    doktorController.poliklinikDoktorlari(val ?? '');
                  },
                ),
              ),
              const SizedBox(height: 16),
              Obx(
                () => DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Doktor Seçin',
                    border: OutlineInputBorder(),
                  ),
                  value: hastaController.selectedDoktor.value.isEmpty
                      ? null
                      : hastaController.selectedDoktor.value,
                  items: doktorController.filtrelenmisDoktorlar
                      .map(
                        (d) => DropdownMenuItem(
                          value: d['id'].toString(),
                          child: Text(d['adSoyad']),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    hastaController.selectedDoktor.value = val ?? '';
                  },
                ),
              ),
              const SizedBox(height: 16),
              Obx(
                () => DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Tarih Seçin',
                    border: OutlineInputBorder(),
                  ),
                  value: hastaController.selectedTarih.value.isEmpty
                      ? null
                      : hastaController.selectedTarih.value,
                  items: hastaController.uygunTarihler
                      .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                      .toList(),
                  onChanged: (val) {
                    hastaController.selectedTarih.value = val ?? '';
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () {
              hastaController.randevuAl(hasta);
              Navigator.pop(context);
            },
            child: const Text('Randevu Al'),
          ),
        ],
      ),
    );
  }

  void _showRandevularimDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Randevularım'),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: hastaController.hastaRandevulari(hasta['tc']),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final randevular = snapshot.data ?? [];

              if (randevular.isEmpty) {
                return const Center(
                  child: Text('Henüz randevunuz bulunmuyor.'),
                );
              }

              return ListView.builder(
                itemCount: randevular.length,
                itemBuilder: (context, index) {
                  final randevu = randevular[index];
                  return Card(
                    child: ListTile(
                      title: Text(randevu['doktorAd'] ?? ''),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Poliklinik: ${randevu['poliklinik']}'),
                          Text('Tarih: ${randevu['tarih']}'),
                          Text('Saat: ${randevu['saat']}'),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          hastaController.randevuIptal(randevu['id']);
                          Navigator.pop(context);
                          _showRandevularimDialog(context);
                        },
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Kapat'),
          ),
        ],
      ),
    );
  }
}
